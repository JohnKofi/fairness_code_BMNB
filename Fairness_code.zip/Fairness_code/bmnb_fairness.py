#!/usr/bin/env python
# coding: utf-8
"""
BMNB (Bias Mitigating Naive Bayes) - Fairness-Aware Classifier
================================================================
Canonical, corrected implementation. Supersedes the duplicated logic
previously split across FINALAFTERREVIEW_BMNB.py and alpha1111.py.

This revision responds directly to the peer-review round (see
Reviewer Comments.docx) and to issues found while re-deriving the
method during that revision:

  R5.1 (double counting of P_group).  The blending partner for a
       group's own likelihood was previously the POOLED global model,
       which is itself partly built from that same group's data (its
       mean is a weighted average of the per-group means). This gives
       alpha a group-size-dependent meaning: near-inert for the
       majority group, doing most of the work for the minority group.
       Fix: each group g is now blended against a "leave-group-out"
       model fit ONLY on data from every OTHER sensitive group. No
       row's data is ever used twice inside its own blended estimate,
       so alpha has one consistent meaning regardless of group size.

  R3.6 (likelihood vs. posterior blending).  The manuscript's Eq. 2
       blends class-conditional LIKELIHOODS P(x|y), but the previous
       code blended POSTERIOR probabilities (predict_proba, which
       already folds in each sub-model's own prior). Fix: we now
       compute raw Gaussian log-likelihoods directly from each
       GaussianNB's theta_/var_, blend those (in probability space,
       via log-sum-exp for numerical stability), and apply a single
       class prior (the target group's own) once, after blending -
       exactly Eq. 1 with the blended likelihood substituted in.

  R3.2 / internal bug (EOD/EMOD/SPD/DI sign convention). The previous
       code derived "privileged" vs "unprivileged" from sorted numeric
       label order (g1 = larger code). That happens to equal
       "privileged" for Adult/Framingham (male=1) but is BACKWARDS for
       ProPublica, where the sensitive code is African_American (1 =
       the historically disadvantaged/unprivileged group). Fix: every
       dataset now carries an explicit privileged/unprivileged value,
       threaded through to calculate_fairness_metrics, so EOD/EMOD/SPD
       consistently mean (privileged - unprivileged) and DI means
       (privileged / unprivileged) everywhere.

  R3.3 (unbounded, asymmetric DI term dominating the composite score).
       |1 - DI| is unbounded above and not symmetric under group
       relabeling (DI=0.5 and DI=2 are equally "unfair" but score
       0.5 and 1.0 respectively). Fix: the composite index uses the
       bounded, symmetric quantity DI_sym = min(DI, 1/DI) in (0, 1].

  Citation fidelity: Agarwal et al. 2023 (ref [21]) define BI as a
       ROOT-MEAN-SQUARE deviation from the ideal value, not a mean
       absolute deviation. We had described (and computed) BI/FS as a
       mean absolute deviation while attributing the formula to them.
       Fixed to match their actual definition (see calculate_fairness_
       metrics). This also resolves the Table 21 "BI=0.0449 but
       FS=0.7025" discrepancy the reviewers flagged: 0.7025 in
       Agarwal et al.'s own Table 1 is the OVERALL, three-attribute
       system Fairness Score (race+gender+marital-status combined),
       not 1-BI_gender; it was never a valid same-attribute comparator
       and is corrected in the rewritten manuscript rather than in code.

  R3.4 (SMOTEENN on ordinally-encoded categoricals can synthesize
       fractional, meaningless categorical codes). Fix: for any
       dataset with categorical columns (Adult), resampling now uses
       SMOTENC (which samples categorical columns by neighbor mode,
       never interpolates them) followed by Edited Nearest Neighbours,
       instead of plain SMOTEENN. Purely-numeric datasets (ProPublica,
       Framingham) still use SMOTEENN, which is exact for them.

  R3.4 / R5 (does resampling distort the sensitive-attribute
       distribution?).  We now record, for every run, the group-share
       before vs. after resampling+NN sensitive-attribute recovery,
       so this can be reported quantitatively rather than asserted.

  R3.7 (need internal baselines on identical splits, not just
       literature numbers from different pipelines) and abstract
       promises (unmitigated NB, reweighing, fair LR reduction) that
       were never actually implemented in the body: this module adds
       genuine, same-split internal baselines: Unmitigated NB,
       Reweighing (Kamiran & Calders 2012, via sample_weight),
       Reject Option Classification (Kamiran, Karim & Zhang 2012 -
       also directly answers Reviewer 1's question about why ROC
       wasn't considered), and a fair logistic-regression reduction
       (fairlearn ExponentiatedGradient under Demographic Parity).

  R3.5 / R5 (ethical/legal implications of using the sensitive
       attribute at prediction time). Not a code fix; addressed in
       the manuscript's new Ethical and Legal Considerations section.
"""

import numpy as np
import pandas as pd

from sklearn.naive_bayes import GaussianNB
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix
)
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from sklearn.neighbors import NearestNeighbors

from imblearn.combine import SMOTEENN
from imblearn.over_sampling import SMOTENC
from imblearn.under_sampling import EditedNearestNeighbours

from fairlearn.reductions import ExponentiatedGradient, DemographicParity

from scipy.stats import wilcoxon

import matplotlib.pyplot as plt
import seaborn as sns


# ==========================================================
# Dataset-specific raw preprocessing
# ==========================================================

# Explicit privileged/unprivileged coding per dataset (R3.2 fix).
# Adult / Framingham: sex-coded 1 = male = historically privileged.
# ProPublica: African_American = 1 = historically UNprivileged; the
# privileged reference group is s=0 (not African-American).

# favorable_label: which value of y is the outcome an individual would
# want. Adult's y=1 (income>$50K) is a favorable outcome in the usual
# resource-allocation sense; Framingham's y=1 (10-year CHD risk) and
# ProPublica's y=1 (predicted recidivism) are ADVERSE outcomes - being
# predicted positive is bad for the individual. EOD/EMOD/SPD/DI remain
# defined purely with respect to y=1 (as in Eq. 8-11) regardless of
# valence, since group-level parity of the y=1 rate is well-defined
# either way; favorable_label is used only where an algorithm needs to
# know which direction constitutes "helping" a group (Reject Option
# Classification's critical-region flip).
DATASET_GROUP_ROLES = {
    "adult":       {"privileged": 1, "unprivileged": 0, "favorable_label": 1},
    "framingham":  {"privileged": 1, "unprivileged": 0, "favorable_label": 0},
    "propublica":  {"privileged": 0, "unprivileged": 1, "favorable_label": 0},
}


def preprocess_data(df, dataset_name):
    """
    Apply dataset-specific row filtering and extract X (raw feature
    DataFrame, may still contain object/categorical columns), y
    (target), and s (sensitive attribute). No encoding/scaling here -
    that must happen strictly after the train/test split (fit on the
    training fold only) to avoid leakage.

    Returns:
        X_df, y, s, cat_cols, group_roles (dict with "privileged" and
        "unprivileged" values of s)
    """
    df = df.copy()

    if dataset_name == 'adult':
        df.replace("?", np.nan, inplace=True)
        df.dropna(inplace=True)
        df.reset_index(drop=True, inplace=True)

        y = df['income'].apply(lambda x: 1 if '>50K' in x else 0).values
        s = df['sex'].apply(lambda x: 1 if x.strip() == 'Male' else 0).values

        X_df = df.drop(['income', 'sex'], axis=1)

    elif dataset_name == 'propublica':
        df.dropna(inplace=True)
        df.reset_index(drop=True, inplace=True)

        y = df['Two_yr_Recidivism'].values
        s = df['African_American'].values

        race_columns = ['African_American', 'Asian', 'Hispanic',
                         'Native_American', 'Other']
        X_df = df.drop(['Two_yr_Recidivism'] + race_columns, axis=1)

    elif dataset_name == 'framingham':
        df.dropna(inplace=True)
        df.reset_index(drop=True, inplace=True)

        y = df['TenYearCHD'].values
        s = df['male'].values

        X_df = df.drop(['TenYearCHD', 'male'], axis=1)

    else:
        raise ValueError(
            "Unsupported dataset_name. Use 'adult', 'propublica', or 'framingham'."
        )

    cat_cols = [
        col for col in X_df.columns
        if X_df[col].dtype == 'object' or isinstance(X_df[col].iloc[0], str)
    ]

    return X_df, y, s, cat_cols, DATASET_GROUP_ROLES[dataset_name]


# ==========================================================
# Train-fold-only encoding / scaling
# ==========================================================

def fit_encoders(X_train_df, cat_cols):
    encoders = {}
    for col in cat_cols:
        le = LabelEncoder()
        le.fit(X_train_df[col].astype(str))
        encoders[col] = le
    return encoders


def apply_encoders(X_df, cat_cols, encoders):
    X_df = X_df.copy()
    for col in cat_cols:
        le = encoders[col]
        known = set(le.classes_)
        X_df[col] = X_df[col].astype(str).apply(
            lambda v: le.transform([v])[0] if v in known else -1
        )
    return X_df


def encode_and_scale(X_train_df, X_val_df, X_test_df, cat_cols):
    encoders = fit_encoders(X_train_df, cat_cols)

    X_train_enc = apply_encoders(X_train_df, cat_cols, encoders)
    X_val_enc = apply_encoders(X_val_df, cat_cols, encoders)
    X_test_enc = apply_encoders(X_test_df, cat_cols, encoders)

    scaler = MinMaxScaler()
    X_train_arr = scaler.fit_transform(X_train_enc.values.astype(float))
    X_val_arr = scaler.transform(X_val_enc.values.astype(float))
    X_test_arr = scaler.transform(X_test_enc.values.astype(float))

    return X_train_arr, X_val_arr, X_test_arr, encoders, scaler


# ==========================================================
# Resampling (R3.4: categorical-safe SMOTE variant)
# ==========================================================

def resample_train(X_train_arr, y_train, cat_col_idx, random_state):
    """
    Balances the training partition on the target label.

    If the dataset has categorical columns (Adult), plain SMOTEENN
    would linearly interpolate ordinal-encoded categories, producing
    fractional codes that do not correspond to any real category
    (Reviewer 3, point 4). SMOTENC instead synthesizes categorical
    columns by neighbor-mode voting, never interpolating them; we then
    apply Edited Nearest Neighbours for the "ENN" cleaning step, so
    the combination is behaviourally equivalent to SMOTEENN but safe
    for mixed-type data. Purely-numeric datasets keep plain SMOTEENN,
    for which this concern does not arise.
    """
    classes, counts = np.unique(y_train, return_counts=True)
    minority_count = counts.min()
    k_neighbors = max(1, min(5, minority_count - 1))

    try:
        if len(cat_col_idx) > 0:
            sm = SMOTENC(categorical_features=cat_col_idx,
                         random_state=random_state, k_neighbors=k_neighbors)
            X_sm, y_sm = sm.fit_resample(X_train_arr, y_train)
            enn = EditedNearestNeighbours()
            X_res, y_res = enn.fit_resample(X_sm, y_sm)
        else:
            sm = SMOTEENN(random_state=random_state,
                          sampling_strategy='auto')
            X_res, y_res = sm.fit_resample(X_train_arr, y_train)
        return X_res, y_res
    except ValueError:
        # Degenerate fold (e.g. too few minority samples for k_neighbors);
        # fall back to the unresampled training partition.
        return X_train_arr, y_train


# ==========================================================
# BMNB Class
# ==========================================================

_LOG_2PI = np.log(2 * np.pi)


class BMNB:
    """
    Bias Mitigating Naive Bayes.

    Blended Likelihood Estimation (BLE): for a row from sensitive
    group g, the class-conditional Gaussian likelihood is a mixture

        P_BMNB(x | y) = alpha * P_g(x | y) + (1 - alpha) * P_-g(x | y)

    where P_g is estimated ONLY from group g's own training rows and
    P_-g ("leave-group-out") is estimated ONLY from rows outside group
    g. Unlike blending against a pooled global model, no row ever
    contributes to its own group's blending partner, so alpha carries
    one consistent meaning regardless of group size (Reviewer 5, point
    3.1). The final posterior applies group g's own class prior once,
    after blending the raw likelihoods (Reviewer 3, point 6).
    """

    def __init__(self, alpha=0.5, class_priors=None):
        self.alpha = alpha
        self.class_priors = class_priors

        self.global_model = None
        self.group_models = {}
        self.complement_models = {}
        self.group_priors = {}
        self.groups = None
        self.thresholds = {}

    # ------------------------------------------------------------
    def fit(self, X, y, sensitive):

        self.global_model = GaussianNB(priors=self._resolve_priors(y))
        self.global_model.fit(X, y)

        self.groups = np.unique(sensitive)
        self.group_models = {}
        self.complement_models = {}
        self.group_priors = {}

        for group in self.groups:
            idx = (sensitive == group)

            own_model = self._fit_or_fallback(X[idx], y[idx])
            comp_model = self._fit_or_fallback(X[~idx], y[~idx])

            self.group_models[group] = own_model
            self.complement_models[group] = comp_model
            # Own-group class prior, aligned to labels [0, 1].
            self.group_priors[group] = self._resolve_priors(y[idx]) \
                if len(np.unique(y[idx])) >= 2 else self._resolve_priors(y)

        return self

    def _fit_or_fallback(self, X_sub, y_sub):
        if len(np.unique(y_sub)) < 2:
            return self.global_model
        model = GaussianNB(priors=self._resolve_priors(y_sub))
        model.fit(X_sub, y_sub)
        return model

    def _resolve_priors(self, y):
        if self.class_priors is not None:
            return self.class_priors
        classes, counts = np.unique(y, return_counts=True)
        if len(classes) < 2:
            return None
        freqs = counts / counts.sum()
        order = np.argsort(classes)
        return list(freqs[order])

    # ------------------------------------------------------------
    # Raw Gaussian class-conditional log-likelihood, replicating
    # GaussianNB's own diagonal-covariance assumption via its public
    # theta_ (per-class means) / var_ (per-class variances).
    # ------------------------------------------------------------
    @staticmethod
    def _log_likelihood(X, model, cls):
        ci = list(model.classes_).index(cls)
        theta = model.theta_[ci]
        var = model.var_[ci]
        return -0.5 * np.sum(_LOG_2PI + np.log(var) + (X - theta) ** 2 / var, axis=1)

    def _blended_log_likelihood(self, X, own_model, comp_model, cls):
        ll_own = self._log_likelihood(X, own_model, cls)
        if self.alpha <= 0.0:
            return self._log_likelihood(X, comp_model, cls)
        if self.alpha >= 1.0:
            return ll_own
        ll_comp = self._log_likelihood(X, comp_model, cls)
        return np.logaddexp(
            np.log(self.alpha) + ll_own,
            np.log(1 - self.alpha) + ll_comp
        )

    def predict_proba(self, X, sensitive):
        n = len(X)
        probs = np.full(n, np.nan)

        for group in self.groups:
            idx = (sensitive == group)
            if not np.any(idx):
                continue

            own_model = self.group_models[group]
            comp_model = self.complement_models[group]
            prior = np.asarray(self.group_priors[group])

            Xg = X[idx]
            ll0 = self._blended_log_likelihood(Xg, own_model, comp_model, 0)
            ll1 = self._blended_log_likelihood(Xg, own_model, comp_model, 1)

            score0 = np.log(prior[0]) + ll0
            score1 = np.log(prior[1]) + ll1

            m = np.maximum(score0, score1)
            e0 = np.exp(score0 - m)
            e1 = np.exp(score1 - m)
            probs[idx] = e1 / (e0 + e1)

        # Rows whose sensitive value was never seen at training time
        # fall back to the pooled global model's posterior.
        unseen = np.isnan(probs)
        if np.any(unseen):
            probs[unseen] = self.global_model.predict_proba(X[unseen])[:, 1]

        return probs

    # ------------------------------------------------------------
    # Adaptive Threshold Calibration (coordinate ascent on FS)
    # ------------------------------------------------------------
    def calibrate_thresholds(self, y_true, probabilities, sensitive,
                              privileged, unprivileged):
        self.thresholds = {}
        candidate_thresholds = np.linspace(0.05, 0.95, 91)
        groups = np.unique(sensitive)
        current_thresholds = {g: 0.50 for g in groups}

        for target_group in groups:
            best_threshold = 0.50
            best_fs = -np.inf

            for threshold in candidate_thresholds:
                temp_thresholds = current_thresholds.copy()
                temp_thresholds[target_group] = threshold

                y_pred = np.zeros(len(probabilities), dtype=int)
                for g in groups:
                    idx = (sensitive == g)
                    y_pred[idx] = (probabilities[idx] >= temp_thresholds[g]).astype(int)

                group_metrics = calculate_group_metrics(y_true, y_pred, sensitive)
                fairness = calculate_fairness_metrics(group_metrics, privileged, unprivileged)

                if fairness["FS"] > best_fs:
                    best_fs = fairness["FS"]
                    best_threshold = threshold

            current_thresholds[target_group] = best_threshold

        self.thresholds = current_thresholds
        return self.thresholds

    def predict(self, X, sensitive):
        probs = self.predict_proba(X, sensitive)
        predictions = np.zeros(len(probs), dtype=int)
        for group in np.unique(sensitive):
            idx = (sensitive == group)
            threshold = self.thresholds.get(group, 0.5)
            predictions[idx] = (probs[idx] >= threshold).astype(int)
        return predictions

    # ------------------------------------------------------------
    def explain_decision(self, X, sensitive, return_dataframe=True):
        blended_probs = self.predict_proba(X, sensitive)
        rows = []

        for i in range(len(X)):
            group = sensitive[i]
            threshold = self.thresholds.get(group, 0.5)

            own_model = self.group_models.get(group, self.global_model)
            comp_model = self.complement_models.get(group, self.global_model)
            own_prob = own_model.predict_proba(X[i:i + 1])[:, 1][0]
            comp_prob = comp_model.predict_proba(X[i:i + 1])[:, 1][0]

            blended = blended_probs[i]
            prediction = int(blended >= threshold)
            margin = blended - threshold

            explanation = (
                f"Group={group}; Own-group posterior={own_prob:.3f}; "
                f"Rest-of-population posterior={comp_prob:.3f}; "
                f"Alpha={self.alpha:.2f}; Blended={blended:.3f}; "
                f"Threshold={threshold:.3f}; Prediction={prediction}; "
                f"Margin={margin:.3f}"
            )

            rows.append({
                "index": i,
                "group": group,
                "own_group_probability": round(own_prob, 4),
                "complement_probability": round(comp_prob, 4),
                "alpha": self.alpha,
                "blended_probability": round(blended, 4),
                "threshold": round(threshold, 4),
                "margin_to_threshold": round(margin, 4),
                "prediction": prediction,
                "decision": "Positive" if prediction else "Negative",
                "explanation": explanation
            })

        if return_dataframe:
            return pd.DataFrame(rows)
        return rows


# ==========================================================
# Group Metrics
# ==========================================================

def calculate_group_metrics(y_true, y_pred, sensitive):
    metrics = {}
    for group in np.unique(sensitive):
        idx = (sensitive == group)
        yt = y_true[idx]
        yp = y_pred[idx]

        TP = np.sum((yt == 1) & (yp == 1))
        TN = np.sum((yt == 0) & (yp == 0))
        FP = np.sum((yt == 0) & (yp == 1))
        FN = np.sum((yt == 1) & (yp == 0))

        TPR = TP / (TP + FN) if (TP + FN) > 0 else 0
        FPR = FP / (FP + TN) if (FP + TN) > 0 else 0
        PPR = np.mean(yp) if len(yp) > 0 else 0

        metrics[group] = {"TPR": TPR, "FPR": FPR, "PPR": PPR, "Support": len(yt)}

    return metrics


# ==========================================================
# Fairness Metrics (R3.2 sign-convention fix; R3.3 bounded DI;
# RMS aggregation matching Agarwal et al. [21]'s actual definition)
# ==========================================================

def calculate_fairness_metrics(group_metrics, privileged, unprivileged):
    p = group_metrics[privileged]
    u = group_metrics[unprivileged]

    EOD = p["TPR"] - u["TPR"]
    EMOD = p["FPR"] - u["FPR"]
    SPD = p["PPR"] - u["PPR"]

    if u["PPR"] > 0 and p["PPR"] > 0:
        DI = p["PPR"] / u["PPR"]
        DI_sym = min(DI, 1.0 / DI)
    elif u["PPR"] == 0 and p["PPR"] == 0:
        DI = 1.0
        DI_sym = 1.0
    else:
        DI = 0.0 if p["PPR"] == 0 else np.inf
        DI_sym = 0.0

    BI = np.sqrt(np.mean([EOD ** 2, EMOD ** 2, SPD ** 2, (1 - DI_sym) ** 2]))
    FS = 1 - BI

    return {"EOD": EOD, "EMOD": EMOD, "SPD": SPD, "DI": DI,
            "DI_sym": DI_sym, "BI": BI, "FS": FS}


# ==========================================================
# Reweighing (Kamiran & Calders, 2012)
# ==========================================================

def compute_reweighing_weights(y, s):
    n = len(y)
    w = np.ones(n, dtype=float)
    for s_val in np.unique(s):
        for y_val in np.unique(y):
            mask = (s == s_val) & (y == y_val)
            n_sy = mask.sum()
            if n_sy == 0:
                continue
            n_s = (s == s_val).sum()
            n_y = (y == y_val).sum()
            w[mask] = (n_s * n_y) / (n * n_sy)
    return w


# ==========================================================
# Reject Option Classification (Kamiran, Karim & Zhang, 2012)
# ==========================================================

def reject_option_predict(probs, sensitive, privileged, unprivileged, theta,
                           favorable_label=1):
    unfavorable_label = 1 - favorable_label
    pred = (probs >= 0.5).astype(int)
    band = np.abs(probs - 0.5) <= theta
    pred[band & (sensitive == unprivileged)] = favorable_label
    pred[band & (sensitive == privileged)] = unfavorable_label
    return pred


def calibrate_reject_option_theta(y_true, probs, sensitive, privileged, unprivileged,
                                   favorable_label=1):
    candidates = np.linspace(0.0, 0.25, 26)
    best_theta, best_fs = 0.0, -np.inf
    for theta in candidates:
        y_pred = reject_option_predict(probs, sensitive, privileged, unprivileged,
                                        theta, favorable_label)
        gm = calculate_group_metrics(y_true, y_pred, sensitive)
        fs = calculate_fairness_metrics(gm, privileged, unprivileged)["FS"]
        if fs > best_fs:
            best_fs, best_theta = fs, theta
    return best_theta


# ==========================================================
# Dataset Labels (framingham corrected: outcome is CHD, not stroke)
# ==========================================================

def get_label_mapping(dataset_name):
    mappings = {
        "adult": {0: "<=50K", 1: ">50K"},
        "propublica": {0: "No Recidivism", 1: "Recidivism"},
        "framingham": {0: "No CHD", 1: "CHD"}
    }
    if dataset_name not in mappings:
        raise ValueError("Unknown dataset.")
    return mappings[dataset_name]


def plot_confusion_matrix(y_true, y_pred, dataset_name, save_path=None):
    labels = get_label_mapping(dataset_name)
    unique = np.unique(np.concatenate((y_true, y_pred)))
    display = [labels[i] for i in unique]

    cm = confusion_matrix(y_true, y_pred, labels=unique)

    plt.figure(figsize=(6, 4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Purples",
                xticklabels=display, yticklabels=display)
    plt.title(f"Confusion Matrix ({dataset_name})")
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=200)
        plt.close()
    else:
        plt.show()


# ==========================================================
# Core Evaluation (leakage-free)
# ==========================================================

METHODS = {
    "Unmitigated NB": "unmitigated",
    "Reweighing": "reweighing",
    "Reject Option": "reject_option",
    "Fair LR (reduction)": "fairlr",
    "BLE Only": "ble",
    "Threshold Only": "threshold",
    "Full BMNB": "full",
}


def evaluate_bmnb(X_df, y, s, dataset_name, cat_cols, group_roles,
                   alpha=0.5, class_priors=None,
                   random_state=42, mode="full", verbose=False):

    privileged = group_roles["privileged"]
    unprivileged = group_roles["unprivileged"]
    favorable_label = group_roles.get("favorable_label", 1)

    # 1. Split FIRST (raw, unencoded data) - test set stays untouched.
    X_train_full_df, X_test_df, y_train_full, y_test, s_train_full, s_test = train_test_split(
        X_df, y, s, test_size=0.20, stratify=y, random_state=random_state
    )
    X_train_df, X_val_df, y_train, y_val, s_train, s_val = train_test_split(
        X_train_full_df, y_train_full, s_train_full,
        test_size=0.20, stratify=y_train_full, random_state=random_state
    )

    # 2. Encode + scale using TRAIN-FOLD-ONLY fits.
    X_train, X_val, X_test, encoders, scaler = encode_and_scale(
        X_train_df, X_val_df, X_test_df, cat_cols
    )
    cat_col_idx = [X_train_df.columns.get_loc(c) for c in cat_cols]

    # 3. Balance the training set only (categorical-safe resampling).
    X_train_resampled, y_train_resampled = resample_train(
        X_train, y_train, cat_col_idx, random_state
    )

    # 4. Recover sensitive attribute for resampled rows via 1-NN in
    #    the scaled feature space (both fit and query side scaled).
    nn = NearestNeighbors(n_neighbors=1)
    nn.fit(X_train)
    _, indices = nn.kneighbors(X_train_resampled)
    s_train_resampled = s_train[indices.flatten()]

    share_before = np.mean(s_train == privileged)
    share_after = np.mean(s_train_resampled == privileged)
    group_share_shift = abs(share_after - share_before)

    # 5. Train BMNB (own-group / leave-group-out models fit here).
    model = BMNB(alpha=alpha, class_priors=class_priors)
    model.fit(X_train_resampled, y_train_resampled, s_train_resampled)

    # 6. Prediction, by mode.
    mode = mode.lower()

    if mode == "unmitigated":
        test_probs = model.global_model.predict_proba(X_test)[:, 1]
        y_pred = (test_probs >= 0.5).astype(int)

    elif mode == "reweighing":
        w = compute_reweighing_weights(y_train_resampled, s_train_resampled)
        rw_model = GaussianNB()
        rw_model.fit(X_train_resampled, y_train_resampled, sample_weight=w)
        test_probs = rw_model.predict_proba(X_test)[:, 1]
        y_pred = (test_probs >= 0.5).astype(int)

    elif mode == "reject_option":
        val_probs = model.global_model.predict_proba(X_val)[:, 1]
        theta = calibrate_reject_option_theta(y_val, val_probs, s_val, privileged, unprivileged, favorable_label)
        test_probs = model.global_model.predict_proba(X_test)[:, 1]
        y_pred = reject_option_predict(test_probs, s_test, privileged, unprivileged, theta, favorable_label)

    elif mode == "fairlr":
        base = LogisticRegression(max_iter=1000)
        reduction = ExponentiatedGradient(
            base, constraints=DemographicParity(), eps=0.02, max_iter=30
        )
        reduction.fit(X_train_resampled, y_train_resampled,
                       sensitive_features=s_train_resampled)
        # ExponentiatedGradient.predict() performs randomized rounding
        # over its classifier ensemble; seed it so results are
        # reproducible and tied to this run's random_state rather than
        # the ambient numpy RNG state.
        y_pred = reduction.predict(X_test, random_state=random_state)

    elif mode == "threshold":
        val_probs = model.global_model.predict_proba(X_val)[:, 1]
        model.calibrate_thresholds(y_val, val_probs, s_val, privileged, unprivileged)
        test_probs = model.global_model.predict_proba(X_test)[:, 1]
        y_pred = np.zeros(len(test_probs), dtype=int)
        for group in model.groups:
            idx = (s_test == group)
            threshold = model.thresholds.get(group, 0.5)
            y_pred[idx] = (test_probs[idx] >= threshold).astype(int)

    elif mode == "ble":
        test_probs = model.predict_proba(X_test, s_test)
        y_pred = (test_probs >= 0.5).astype(int)

    elif mode == "full":
        val_probs = model.predict_proba(X_val, s_val)
        model.calibrate_thresholds(y_val, val_probs, s_val, privileged, unprivileged)
        y_pred = model.predict(X_test, s_test)

    else:
        raise ValueError(f"Unknown mode: {mode}")

    accuracy = accuracy_score(y_test, y_pred)
    group_metrics = calculate_group_metrics(y_test, y_pred, s_test)
    fairness = calculate_fairness_metrics(group_metrics, privileged, unprivileged)

    if verbose:
        print(f"[{dataset_name}/{mode}] Accuracy={accuracy:.3f} FS={fairness['FS']:.3f}")

    return {
        "accuracy": accuracy,
        "precision": precision_score(y_test, y_pred, zero_division=0),
        "recall": recall_score(y_test, y_pred, zero_division=0),
        "f1": f1_score(y_test, y_pred, zero_division=0),
        "BI": fairness["BI"], "FS": fairness["FS"],
        "EOD": fairness["EOD"], "EMOD": fairness["EMOD"],
        "SPD": fairness["SPD"], "DI": fairness["DI"],
        "group_share_shift": group_share_shift,
    }


# ==========================================================
# Repeated Experiment (repeated hold-out)
# ==========================================================

def repeated_experiment(X_df, y, s, dataset_name, cat_cols, group_roles,
                         repeats=10, alpha=0.5, class_priors=None,
                         methods=None):
    methods = methods or METHODS
    results = {}
    for method, mode in methods.items():
        results[method] = []
        for seed in range(repeats):
            metrics = evaluate_bmnb(
                X_df, y, s, dataset_name, cat_cols, group_roles,
                alpha=alpha, class_priors=class_priors,
                random_state=seed, mode=mode, verbose=False
            )
            results[method].append(metrics)
    return results


# ==========================================================
# Genuine K-Fold Cross-Validation variant
# ==========================================================

def evaluate_bmnb_kfold(X_df, y, s, dataset_name, cat_cols, group_roles,
                         alpha=0.5, class_priors=None,
                         n_splits=5, random_state=42, mode="full", verbose=False):

    privileged = group_roles["privileged"]
    unprivileged = group_roles["unprivileged"]
    favorable_label = group_roles.get("favorable_label", 1)

    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=random_state)

    X_arr = X_df.reset_index(drop=True)
    y_arr = np.asarray(y)
    s_arr = np.asarray(s)

    fold_results = []

    for fold_idx, (train_idx, test_idx) in enumerate(skf.split(X_arr, y_arr)):
        X_train_full_df = X_arr.iloc[train_idx].reset_index(drop=True)
        X_test_df = X_arr.iloc[test_idx].reset_index(drop=True)
        y_train_full, y_test = y_arr[train_idx], y_arr[test_idx]
        s_train_full, s_test = s_arr[train_idx], s_arr[test_idx]

        X_train_df, X_val_df, y_train, y_val, s_train, s_val = train_test_split(
            X_train_full_df, y_train_full, s_train_full,
            test_size=0.20, stratify=y_train_full, random_state=random_state
        )

        X_train, X_val, X_test, encoders, scaler = encode_and_scale(
            X_train_df, X_val_df, X_test_df, cat_cols
        )
        cat_col_idx = [X_train_df.columns.get_loc(c) for c in cat_cols]

        X_train_resampled, y_train_resampled = resample_train(
            X_train, y_train, cat_col_idx, random_state
        )

        nn = NearestNeighbors(n_neighbors=1)
        nn.fit(X_train)
        _, indices = nn.kneighbors(X_train_resampled)
        s_train_resampled = s_train[indices.flatten()]

        share_before = np.mean(s_train == privileged)
        share_after = np.mean(s_train_resampled == privileged)
        group_share_shift = abs(share_after - share_before)

        model = BMNB(alpha=alpha, class_priors=class_priors)
        model.fit(X_train_resampled, y_train_resampled, s_train_resampled)

        mode_l = mode.lower()

        if mode_l == "unmitigated":
            test_probs = model.global_model.predict_proba(X_test)[:, 1]
            y_pred = (test_probs >= 0.5).astype(int)

        elif mode_l == "reweighing":
            w = compute_reweighing_weights(y_train_resampled, s_train_resampled)
            rw_model = GaussianNB()
            rw_model.fit(X_train_resampled, y_train_resampled, sample_weight=w)
            test_probs = rw_model.predict_proba(X_test)[:, 1]
            y_pred = (test_probs >= 0.5).astype(int)

        elif mode_l == "reject_option":
            val_probs = model.global_model.predict_proba(X_val)[:, 1]
            theta = calibrate_reject_option_theta(y_val, val_probs, s_val, privileged, unprivileged, favorable_label)
            test_probs = model.global_model.predict_proba(X_test)[:, 1]
            y_pred = reject_option_predict(test_probs, s_test, privileged, unprivileged, theta, favorable_label)

        elif mode_l == "fairlr":
            base = LogisticRegression(max_iter=1000)
            reduction = ExponentiatedGradient(
                base, constraints=DemographicParity(), eps=0.02, max_iter=30
            )
            reduction.fit(X_train_resampled, y_train_resampled,
                           sensitive_features=s_train_resampled)
            # Seed the randomized-rounding prediction step per-fold for
            # reproducibility (see evaluate_bmnb for the same fix).
            y_pred = reduction.predict(X_test, random_state=random_state + fold_idx)

        elif mode_l == "threshold":
            val_probs = model.global_model.predict_proba(X_val)[:, 1]
            model.calibrate_thresholds(y_val, val_probs, s_val, privileged, unprivileged)
            test_probs = model.global_model.predict_proba(X_test)[:, 1]
            y_pred = np.zeros(len(test_probs), dtype=int)
            for group in model.groups:
                idx = (s_test == group)
                threshold = model.thresholds.get(group, 0.5)
                y_pred[idx] = (test_probs[idx] >= threshold).astype(int)

        elif mode_l == "ble":
            test_probs = model.predict_proba(X_test, s_test)
            y_pred = (test_probs >= 0.5).astype(int)

        elif mode_l == "full":
            val_probs = model.predict_proba(X_val, s_val)
            model.calibrate_thresholds(y_val, val_probs, s_val, privileged, unprivileged)
            y_pred = model.predict(X_test, s_test)

        else:
            raise ValueError(f"Unknown mode: {mode}")

        accuracy = accuracy_score(y_test, y_pred)
        group_metrics = calculate_group_metrics(y_test, y_pred, s_test)
        fairness = calculate_fairness_metrics(group_metrics, privileged, unprivileged)

        if verbose:
            print(f"Fold {fold_idx + 1}/{n_splits} [{mode}] "
                  f"Accuracy={accuracy:.3f} FS={fairness['FS']:.3f}")

        fold_results.append({
            "accuracy": accuracy,
            "precision": precision_score(y_test, y_pred, zero_division=0),
            "recall": recall_score(y_test, y_pred, zero_division=0),
            "f1": f1_score(y_test, y_pred, zero_division=0),
            "BI": fairness["BI"], "FS": fairness["FS"],
            "EOD": fairness["EOD"], "EMOD": fairness["EMOD"],
            "SPD": fairness["SPD"], "DI": fairness["DI"],
            "group_share_shift": group_share_shift,
        })

    return fold_results


# ==========================================================
# Result Summary
# ==========================================================

def summarize_results(results):
    summary = []
    for method, values in results.items():
        row = {"Method": method}
        for metric in ["accuracy", "precision", "recall", "f1",
                       "BI", "FS", "EOD", "EMOD", "SPD", "DI"]:
            vals = [x[metric] for x in values]
            row[metric.capitalize() if metric in ("accuracy","precision","recall") else metric] = \
                f"{np.mean(vals):.3f} ± {np.std(vals):.3f}"
        summary.append(row)
    return pd.DataFrame(summary)


def numeric_summary(results):
    """Tidy numeric (non-string-formatted) mean/std per method."""
    rows = []
    for method, values in results.items():
        row = {"Method": method}
        for metric in ["accuracy", "precision", "recall", "f1",
                       "BI", "FS", "EOD", "EMOD", "SPD", "DI", "group_share_shift"]:
            vals = [x[metric] for x in values]
            row[f"{metric}_mean"] = np.mean(vals)
            row[f"{metric}_std"] = np.std(vals)
        rows.append(row)
    return pd.DataFrame(rows)


# ==========================================================
# Wilcoxon Signed Rank Test
# ==========================================================

def wilcoxon_test(results, method1, method2, metric):
    values1 = [x[metric] for x in results[method1]]
    values2 = [x[metric] for x in results[method2]]
    try:
        statistic, p_value = wilcoxon(values1, values2)
    except ValueError:
        statistic, p_value = np.nan, np.nan
    return {
        "Comparison": f"{method1} vs {method2}",
        "Metric": metric,
        "Statistic": round(statistic, 3) if not np.isnan(statistic) else statistic,
        "p-value": round(p_value, 4) if not np.isnan(p_value) else p_value
    }


# ==========================================================
# Experiment 1 runners
# ==========================================================

def run_dataset(df, dataset_name, repeats=10, alpha=0.5, class_priors=None):
    X_df, y, s, cat_cols, group_roles = preprocess_data(df, dataset_name)
    results = repeated_experiment(
        X_df, y, s, dataset_name, cat_cols, group_roles,
        repeats=repeats, alpha=alpha, class_priors=class_priors
    )
    summary = summarize_results(results)
    return results, summary


def run_dataset_kfold(df, dataset_name, n_splits=5, alpha=0.5, class_priors=None,
                       methods=None):
    X_df, y, s, cat_cols, group_roles = preprocess_data(df, dataset_name)
    methods = methods or METHODS
    results = {}
    for method, mode in methods.items():
        results[method] = evaluate_bmnb_kfold(
            X_df, y, s, dataset_name, cat_cols, group_roles,
            alpha=alpha, class_priors=class_priors,
            n_splits=n_splits, mode=mode, verbose=False
        )
    summary = summarize_results(results)
    return results, summary


# ==========================================================
# Experiment 2: Alpha sensitivity
# ==========================================================

DEFAULT_ALPHAS = (0.00, 0.25, 0.50, 0.75, 1.00)


def run_alpha_sensitivity_kfold(df, dataset_name, alphas=DEFAULT_ALPHAS,
                                 n_splits=5, class_priors=None, mode="full",
                                 random_state=42, verbose=False):
    X_df, y, s, cat_cols, group_roles = preprocess_data(df, dataset_name)
    results_by_alpha = {}
    for a in alphas:
        label = f"alpha={a:.2f}"
        results_by_alpha[label] = evaluate_bmnb_kfold(
            X_df, y, s, dataset_name, cat_cols, group_roles,
            alpha=a, class_priors=class_priors,
            n_splits=n_splits, random_state=random_state,
            mode=mode, verbose=verbose
        )
    return results_by_alpha, summarize_results(results_by_alpha)


def run_alpha_sensitivity_repeated(df, dataset_name, alphas=DEFAULT_ALPHAS,
                                    repeats=10, class_priors=None, mode="full",
                                    verbose=False):
    X_df, y, s, cat_cols, group_roles = preprocess_data(df, dataset_name)
    results_by_alpha = {}
    for a in alphas:
        label = f"alpha={a:.2f}"
        runs = []
        for seed in range(repeats):
            metrics = evaluate_bmnb(
                X_df, y, s, dataset_name, cat_cols, group_roles,
                alpha=a, class_priors=class_priors,
                random_state=seed, mode=mode, verbose=False
            )
            runs.append(metrics)
        results_by_alpha[label] = runs
    return results_by_alpha, summarize_results(results_by_alpha)


def alpha_wilcoxon_tests(results_by_alpha, alphas=DEFAULT_ALPHAS,
                          baseline_alpha=0.50, metrics=("FS", "accuracy")):
    baseline_label = f"alpha={baseline_alpha:.2f}"
    rows = []
    for a in alphas:
        if abs(a - baseline_alpha) < 1e-9:
            continue
        label = f"alpha={a:.2f}"
        for metric in metrics:
            rows.append(wilcoxon_test(results_by_alpha, label, baseline_label, metric))
    return rows


def plot_alpha_sensitivity(numeric_df, dataset_name, save_path=None,
                            performance_metric="accuracy"):
    fig, ax1 = plt.subplots(figsize=(7, 5))
    color1 = "tab:blue"
    ax1.set_xlabel("Alpha (blending coefficient)")
    ax1.set_ylabel(performance_metric.capitalize(), color=color1)
    ax1.errorbar(
        numeric_df["alpha"], numeric_df[f"{performance_metric}_mean"],
        yerr=numeric_df[f"{performance_metric}_std"],
        marker="o", color=color1, capsize=4, label=performance_metric.capitalize()
    )
    ax1.tick_params(axis="y", labelcolor=color1)
    ax1.set_ylim(0, 1)

    ax2 = ax1.twinx()
    color2 = "tab:red"
    ax2.set_ylabel("Fairness Score (FS)", color=color2)
    ax2.errorbar(
        numeric_df["alpha"], numeric_df["FS_mean"], yerr=numeric_df["FS_std"],
        marker="s", color=color2, capsize=4, label="FS"
    )
    ax2.tick_params(axis="y", labelcolor=color2)
    ax2.set_ylim(0, 1)

    plt.title(f"Fairness-Accuracy Trade-off vs. Alpha ({dataset_name})")
    fig.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=200)
        plt.close()
    else:
        plt.show()
