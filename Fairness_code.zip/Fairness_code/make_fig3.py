import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle

fig, ax = plt.subplots(figsize=(12, 7.2))
ax.set_xlim(0, 12)
ax.set_ylim(0, 7.2)
ax.axis("off")

ax.text(6, 6.85, "Fairness-Aware Pipeline for Bias Mitigation", ha="center",
        fontsize=15, fontweight="bold")

def funnel(cy, w, title, sub, color):
    box = FancyBboxPatch((6 - w/2, cy - 0.5), w, 1.0, boxstyle="round,pad=0.02",
                          linewidth=1.2, edgecolor="#333", facecolor=color)
    ax.add_patch(box)
    ax.text(6, cy + 0.18, title, ha="center", fontsize=12, fontweight="bold")
    ax.text(6, cy - 0.2, sub, ha="center", fontsize=9)

funnel(5.6, 4.6, "Preprocessing", "Cleaning, ordinal encoding, min-max scaling,\nSMOTENC+ENN (categorical-safe), 1-NN sensitive-attr. recovery", "#bcd9f0")
funnel(4.0, 4.0, "In-Processing", "Own-group vs. leave-group-out Gaussian NB;\nBlended Likelihood Estimation (BLE), tunable α", "#c8e6c0")
funnel(2.4, 3.4, "Post-Processing", "Adaptive per-group threshold calibration\n(coordinate ascent, 91 candidates/group, maximizes FS)", "#f7e2a6")

for y1, y2 in [(5.1, 4.5), (3.5, 2.9)]:
    ax.add_patch(FancyArrowPatch((6, y1), (6, y2), arrowstyle="-|>", mutation_scale=18, color="#333"))

ax.add_patch(FancyArrowPatch((6, 1.9), (6, 1.3), arrowstyle="-|>", mutation_scale=18, color="#333"))
final = Circle((6, 0.85), 0.55, facecolor="#d9b8ea", edgecolor="#333", linewidth=1.2)
ax.add_patch(final)
ax.text(6, 0.85, "Full\nBMNB", ha="center", va="center", fontsize=9.5, fontweight="bold")

# right-side annotation boxes
def note(cy, title, lines, color):
    box = FancyBboxPatch((8.5, cy - 0.55), 3.2, 1.35, boxstyle="round,pad=0.02",
                          linewidth=1.0, edgecolor="#333", facecolor=color)
    ax.add_patch(box)
    ax.text(10.1, cy + 0.55, title, ha="center", fontsize=10, fontweight="bold")
    ax.text(10.1, cy - 0.1, lines, ha="center", fontsize=8.2, linespacing=1.5)

note(5.6, "Internal baselines\n(same splits)", "Unmitigated NB · Reweighing\nReject Option · Fair LR reduction", "#eef0f0")
note(4.0, "Bounded composite\nfairness index", r"$BI=\sqrt{\mathrm{mean}[EOD^2,EMOD^2,SPD^2,(1-DI_{sym})^2]}$"+"\n"+r"$DI_{sym}=\min(DI,1/DI),\ FS=1-BI$", "#eef0f0")
note(2.4, "Group-share\ndiagnostic", "Sensitive-attribute share before vs.\nafter resampling logged every run", "#eef0f0")

for cy in [5.6, 4.0, 2.4]:
    ax.add_patch(FancyArrowPatch((8.3, cy), (8.5, cy), arrowstyle="-", linestyle=":",
                                  mutation_scale=1, color="#777"))

plt.tight_layout()
plt.savefig("figures/fig3_pipeline.png", dpi=220, bbox_inches="tight")
print("saved")
