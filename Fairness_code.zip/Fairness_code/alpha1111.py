#!/usr/bin/env python
# coding: utf-8
"""
SUPERSEDED - kept only as a backward-compatible import shim.
=================================================================
This file used to contain a full second copy of the entire BMNB
pipeline (duplicated from FINALAFTERREVIEW_BMNB.py) plus the
Experiment 2 (alpha-sensitivity) runner functions. The duplicated
pipeline code has been consolidated into bmnb_fairness.py (see that
module's docstring for the full list of corrections made during the
peer-review revision), and run_experiments.py is the script that
actually runs Experiment 1 and Experiment 2 for the revised
manuscript, for all three datasets, saving results to results/.

This file re-exports bmnb_fairness's public names, including the
alpha-sensitivity helpers, so any external script that still does
`from alpha1111 import run_experiment2_alpha_sensitivity` (etc.)
keeps working unchanged.
"""

from bmnb_fairness import *  # noqa: F401,F403
from bmnb_fairness import (
    preprocess_data, evaluate_bmnb, evaluate_bmnb_kfold,
    repeated_experiment, run_dataset, run_dataset_kfold,
    summarize_results, wilcoxon_test, BMNB, METHODS,
    DEFAULT_ALPHAS, run_alpha_sensitivity_kfold,
    run_alpha_sensitivity_repeated, alpha_wilcoxon_tests,
    plot_alpha_sensitivity, numeric_summary,
)


def run_experiment2_alpha_sensitivity(df, dataset_name,
                                       alphas=DEFAULT_ALPHAS,
                                       n_splits=5, repeats=10,
                                       class_priors=None,
                                       mode="full",
                                       baseline_alpha=0.50,
                                       make_plot=True):
    """Kept for backward compatibility; see run_experiments.py for the
    version actually used to produce the revised manuscript's results."""
    kfold_results, kfold_summary = run_alpha_sensitivity_kfold(
        df, dataset_name, alphas=alphas, n_splits=n_splits,
        class_priors=class_priors, mode=mode
    )
    repeated_results, repeated_summary = run_alpha_sensitivity_repeated(
        df, dataset_name, alphas=alphas, repeats=repeats,
        class_priors=class_priors, mode=mode
    )
    kfold_wilcoxon = alpha_wilcoxon_tests(
        kfold_results, alphas=alphas, baseline_alpha=baseline_alpha
    )
    if make_plot:
        numeric_df = numeric_summary(kfold_results)
        plot_alpha_sensitivity(numeric_df, dataset_name)
    return {
        "kfold_results": kfold_results,
        "kfold_summary": kfold_summary,
        "repeated_results": repeated_results,
        "repeated_summary": repeated_summary,
        "kfold_wilcoxon_vs_baseline": kfold_wilcoxon,
    }


def main():
    import pandas as pd
    adult_df = pd.read_csv("data/adult.csv")
    run_dataset(adult_df, "adult")
    run_experiment2_alpha_sensitivity(adult_df, "adult")


if __name__ == "__main__":
    main()
