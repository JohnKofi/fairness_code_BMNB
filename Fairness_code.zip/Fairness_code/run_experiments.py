#!/usr/bin/env python
"""
Runs the full, corrected BMNB experiment suite for the revised
manuscript: Experiment 1 (7-method comparison under 5-fold CV and
10x repeated hold-out) and Experiment 2 (alpha sensitivity), for all
three datasets. Saves every numeric result to results/*.json and
results/*.csv, and the two alpha-sensitivity figures to results/*.png.
"""
import json
import time
import numpy as np
import pandas as pd

from bmnb_fairness import (
    preprocess_data, repeated_experiment, evaluate_bmnb_kfold,
    summarize_results, numeric_summary, wilcoxon_test, METHODS,
    run_alpha_sensitivity_kfold, run_alpha_sensitivity_repeated,
    alpha_wilcoxon_tests, plot_alpha_sensitivity, DEFAULT_ALPHAS,
)

RESULTS_DIR = "results"
import os
os.makedirs(RESULTS_DIR, exist_ok=True)


def to_jsonable(x):
    if isinstance(x, dict):
        return {k: to_jsonable(v) for k, v in x.items()}
    if isinstance(x, list):
        return [to_jsonable(v) for v in x]
    if isinstance(x, (np.floating, np.integer)):
        return float(x)
    return x


def save_json(obj, name):
    with open(f"{RESULTS_DIR}/{name}.json", "w") as f:
        json.dump(to_jsonable(obj), f, indent=2)


DATASETS = {
    "adult": "data/adult.csv",
    "propublica": "data/propublica.csv",
    "framingham": "data/framingham.csv",
}

ALPHA_DEFAULT = 0.5


def run_experiment1(name, path):
    print(f"\n=== Experiment 1: {name} ===", flush=True)
    df = pd.read_csv(path)
    X_df, y, s, cat_cols, roles = preprocess_data(df, name)

    t0 = time.time()
    kfold_results = {}
    for method, mode in METHODS.items():
        print(f"  [kfold] {method} ...", flush=True)
        kfold_results[method] = evaluate_bmnb_kfold(
            X_df, y, s, name, cat_cols, roles,
            alpha=ALPHA_DEFAULT, n_splits=5, mode=mode, verbose=False
        )
    print(f"  kfold done in {time.time()-t0:.1f}s", flush=True)

    t0 = time.time()
    holdout_results = repeated_experiment(
        X_df, y, s, name, cat_cols, roles,
        repeats=10, alpha=ALPHA_DEFAULT
    )
    print(f"  holdout done in {time.time()-t0:.1f}s", flush=True)

    kfold_summary = summarize_results(kfold_results)
    holdout_summary = summarize_results(holdout_results)
    kfold_numeric = numeric_summary(kfold_results)
    holdout_numeric = numeric_summary(holdout_results)

    wilcoxon_rows = []
    for protocol, results in [("kfold", kfold_results), ("holdout", holdout_results)]:
        for m1, m2 in [("Full BMNB", "Threshold Only"),
                       ("Full BMNB", "BLE Only"),
                       ("Full BMNB", "Reweighing"),
                       ("Full BMNB", "Unmitigated NB"),
                       ("Full BMNB", "Fair LR (reduction)")]:
            for metric in ["FS", "accuracy"]:
                row = wilcoxon_test(results, m1, m2, metric)
                row["protocol"] = protocol
                row["dataset"] = name
                wilcoxon_rows.append(row)

    save_json(kfold_results, f"{name}_exp1_kfold_raw")
    save_json(holdout_results, f"{name}_exp1_holdout_raw")
    kfold_summary.to_csv(f"{RESULTS_DIR}/{name}_exp1_kfold_summary.csv", index=False)
    holdout_summary.to_csv(f"{RESULTS_DIR}/{name}_exp1_holdout_summary.csv", index=False)
    kfold_numeric.to_csv(f"{RESULTS_DIR}/{name}_exp1_kfold_numeric.csv", index=False)
    holdout_numeric.to_csv(f"{RESULTS_DIR}/{name}_exp1_holdout_numeric.csv", index=False)
    pd.DataFrame(wilcoxon_rows).to_csv(f"{RESULTS_DIR}/{name}_exp1_wilcoxon.csv", index=False)

    print(f"=== {name} kfold summary ===\n{kfold_summary}\n", flush=True)
    print(f"=== {name} holdout summary ===\n{holdout_summary}\n", flush=True)


def run_experiment2(name, path):
    print(f"\n=== Experiment 2 (alpha sensitivity): {name} ===", flush=True)
    df = pd.read_csv(path)

    t0 = time.time()
    kfold_results, kfold_summary = run_alpha_sensitivity_kfold(
        df, name, alphas=DEFAULT_ALPHAS, n_splits=5
    )
    print(f"  alpha kfold done in {time.time()-t0:.1f}s", flush=True)

    t0 = time.time()
    holdout_results, holdout_summary = run_alpha_sensitivity_repeated(
        df, name, alphas=DEFAULT_ALPHAS, repeats=10
    )
    print(f"  alpha holdout done in {time.time()-t0:.1f}s", flush=True)

    kfold_wilcoxon = alpha_wilcoxon_tests(kfold_results, alphas=DEFAULT_ALPHAS)
    holdout_wilcoxon = alpha_wilcoxon_tests(holdout_results, alphas=DEFAULT_ALPHAS)

    save_json(kfold_results, f"{name}_exp2_kfold_raw")
    save_json(holdout_results, f"{name}_exp2_holdout_raw")
    kfold_summary.to_csv(f"{RESULTS_DIR}/{name}_exp2_kfold_summary.csv", index=False)
    holdout_summary.to_csv(f"{RESULTS_DIR}/{name}_exp2_holdout_summary.csv", index=False)
    pd.DataFrame(kfold_wilcoxon).to_csv(f"{RESULTS_DIR}/{name}_exp2_kfold_wilcoxon.csv", index=False)
    pd.DataFrame(holdout_wilcoxon).to_csv(f"{RESULTS_DIR}/{name}_exp2_holdout_wilcoxon.csv", index=False)

    numeric_df = numeric_summary(kfold_results).rename(columns={"Method": "alpha_label"})
    numeric_df["alpha"] = [float(l.split("=")[1]) for l in numeric_df["alpha_label"]]
    numeric_df = numeric_df.sort_values("alpha")
    numeric_df.to_csv(f"{RESULTS_DIR}/{name}_exp2_kfold_numeric.csv", index=False)
    plot_alpha_sensitivity(numeric_df, name, save_path=f"{RESULTS_DIR}/{name}_alpha_sensitivity.png")

    print(f"=== {name} alpha kfold summary ===\n{kfold_summary}\n", flush=True)
    print(f"=== {name} alpha holdout summary ===\n{holdout_summary}\n", flush=True)


if __name__ == "__main__":
    overall_t0 = time.time()
    # Smaller datasets first so partial results are available quickly.
    order = ["framingham", "propublica", "adult"]
    for name in order:
        run_experiment1(name, DATASETS[name])
    for name in order:
        run_experiment2(name, DATASETS[name])
    print(f"\nALL DONE in {time.time()-overall_t0:.1f}s", flush=True)
