#!/usr/bin/env python
# coding: utf-8
"""
SUPERSEDED - kept only as a backward-compatible import shim.
=================================================================
This file and alpha1111.py used to contain two near-identical, ~1000
line copies of the BMNB pipeline (the entire preprocessing/model/
metrics/experiment-runner stack), which is exactly the kind of
duplication that let bugs get fixed in one copy and not the other.

Both the original implementation AND the corrections made during the
peer-review revision (leave-group-out blended likelihood instead of
double-counted pooled-global blending; explicit privileged/
unprivileged fairness-metric convention instead of sorted numeric
coding; bounded/symmetric composite Bias Index and Fairness Score;
SMOTENC-based categorical-safe resampling; internal Unmitigated NB /
Reweighing / Reject Option / Fair-LR-reduction baselines - see
bmnb_fairness.py's module docstring for the full list) now live in a
single canonical module, bmnb_fairness.py. run_experiments.py is the
script that actually runs every experiment reported in the revised
manuscript.

This file re-exports bmnb_fairness's public names so any external
script that still does `from FINALAFTERREVIEW_BMNB import evaluate_bmnb`
(etc.) keeps working unchanged.
"""

from bmnb_fairness import *  # noqa: F401,F403
from bmnb_fairness import (
    preprocess_data, evaluate_bmnb, evaluate_bmnb_kfold,
    repeated_experiment, run_dataset, run_dataset_kfold,
    summarize_results, wilcoxon_test, BMNB, METHODS,
)


def main():
    import pandas as pd
    adult_df = pd.read_csv("data/adult.csv")
    run_dataset(adult_df, "adult")
    run_dataset_kfold(adult_df, "adult", n_splits=5)


if __name__ == "__main__":
    main()
