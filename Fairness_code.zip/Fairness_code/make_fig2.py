import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

fig, ax = plt.subplots(figsize=(11, 4.2))
ax.set_xlim(0, 11)
ax.set_ylim(0, 4.2)
ax.axis("off")

# Outer dashed box
outer = FancyBboxPatch((0.15, 0.25), 6.0, 3.7, boxstyle="round,pad=0.02",
                        linewidth=1.5, edgecolor="#4a7a3a", facecolor="none",
                        linestyle="--")
ax.add_patch(outer)
ax.text(0.35, 3.75, "In-Processing", fontsize=12, fontweight="bold")

def circle_box(cx, cy, w, h, title, sub, color):
    box = FancyBboxPatch((cx - w/2, cy - h/2), w, h,
                          boxstyle="round,pad=0.02,rounding_size=0.5",
                          linewidth=1.2, edgecolor="#333", facecolor=color)
    ax.add_patch(box)
    ax.text(cx, cy + 0.18, title, ha="center", va="center", fontsize=10.5, fontweight="bold")
    ax.text(cx, cy - 0.32, sub, ha="center", va="center", fontsize=9.5)

circle_box(1.7, 2.85, 2.4, 1.15, "Own-Group Model", r"$P_g(x\mid y)$, weight $\alpha$", "#e7c6f0")
circle_box(4.5, 2.85, 2.9, 1.15, "Rest-of-Population Model", r"$P_{-g}(x\mid y)$, weight $1-\alpha$"+"\n(leave-group-out)", "#e7c6f0")

arrow = FancyArrowPatch((3.0, 2.3), (3.3, 1.55), connectionstyle="arc3,rad=-0.3",
                         arrowstyle="-|>", mutation_scale=15, color="#4a7a3a")
ax.add_patch(arrow)
arrow2 = FancyArrowPatch((4.0, 2.3), (3.7, 1.55), connectionstyle="arc3,rad=0.3",
                          arrowstyle="-|>", mutation_scale=15, color="#4a7a3a")
ax.add_patch(arrow2)

blend_box = FancyBboxPatch((0.7, 0.5), 4.9, 0.9, boxstyle="round,pad=0.02",
                            linewidth=1.2, edgecolor="#333", facecolor="#e7c6f0")
ax.add_patch(blend_box)
ax.text(3.15, 1.08, "Blended Likelihood Estimate", ha="center", fontsize=10.5, fontweight="bold")
ax.text(3.15, 0.72,
        r"$P_{BMNB}(x\mid y)=\alpha P_g(x\mid y)+(1-\alpha)P_{-g}(x\mid y),\ \alpha\in[0,1]$",
        ha="center", fontsize=9.5)

main_arrow = FancyArrowPatch((6.2, 1.0), (7.0, 1.0), arrowstyle="-|>", mutation_scale=20, color="#333")
ax.add_patch(main_arrow)

out_box = FancyBboxPatch((7.1, 0.5), 3.6, 1.0, boxstyle="round,pad=0.02",
                          linewidth=1.2, edgecolor="#333", facecolor="#e7c6f0")
ax.add_patch(out_box)
ax.text(8.9, 1.1, "Output Calibration:\nAdaptive Thresholding", ha="center", fontsize=10, fontweight="bold")
ax.text(8.9, 0.68,
        r"$\hat Y=1$ if $P(Y{=}1\mid X,S{=}g)\geq\tau_g$, else $0$",
        ha="center", fontsize=9)

plt.tight_layout()
plt.savefig("figures/fig2_ble_pipeline.png", dpi=220, bbox_inches="tight")
print("saved")
