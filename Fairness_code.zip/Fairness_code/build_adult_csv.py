import pandas as pd

cols = ["age","workclass","fnlwgt","education","education-num","marital-status",
        "occupation","relationship","race","sex","capital-gain","capital-loss",
        "hours-per-week","native-country","income"]

train = pd.read_csv("adult.data", header=None, names=cols, skipinitialspace=True)
test = pd.read_csv("adult.test", header=None, names=cols, skipinitialspace=True, skiprows=1)

test["income"] = test["income"].str.replace(".", "", regex=False)

df = pd.concat([train, test], ignore_index=True)
for c in df.columns:
    if df[c].dtype == object:
        df[c] = df[c].str.strip()

df.to_csv("data/adult.csv", index=False)
print(df.shape)
print(df["income"].value_counts())
print(df["sex"].value_counts())
